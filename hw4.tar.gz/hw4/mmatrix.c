#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include<sys/types.h>
#include<sys/stat.h>
#define NUM_THREADS 10

int **A;
int **B;
int **C;
struct v {
   int i; /* row */
   int j; /* column */
   int size;/* size of matrix */
};

void *runner(void *param); /* the thread */

int main(int argc, char *argv[]) 
{
   int i,j,value; 
   int count = 0;                  
         
         //open the file 
        FILE *fp;
        //int value;
        char buffer[80];
        
        if(argc < 2)
        	{
        		printf("Invalid number of arguments\n");
     		}
   		else
   		{
   			if((fp =fopen(argv[1],"r"))==NULL)
				{
					printf("cannot open file \n");
					exit(0);
				}
				else
				{
					fgets(buffer,80,fp);
					value = atoi(buffer);
					//Memory allocation
					A = (int**) malloc(value*sizeof(int*));
					B = (int**) malloc(value*sizeof(int*));
					C = (int**) malloc(value*sizeof(int*));
					for(i=0; i<value; i++)
					{
						A[i] =(int*)calloc(value,sizeof(int));
						B[i] =(int*)calloc(value,sizeof(int));
						C[i] =(int*)calloc(value,sizeof(int));
					}
					for( i=0; i<2*value; i++)
					{
						fgets(buffer,80,fp);
						char delim [] = {' '};
						char *p = strtok(buffer, delim);
						//buffer[0] = NULL;
						int j = 0;
						while(p != NULL)
						{
							if(i<value)
							{
								A[i][j] = atoi(p);
								printf("\t%d",A[i][j]);
							}
							else
							{
								B[i-value][j] = atoi(p);
								printf("\t%d",B[i-value][j]);
							}
							j++;
							p = strtok(NULL, delim);															
						}
						if(i==value-1)
						{
							printf("\n");
						}
						printf("\t\n");
					}	
				}
			}
         fclose(fp);
         pthread_t tid[value*value];       //Thread ID
          for(i = 0; i < value; i++) 
			 {
  				 for(j = 0; j < value; j++) 
  				 {
					//Assign a row and column for each thread
					struct v *data = (struct v *) malloc(sizeof(struct v));
					data->i = i;
					data->j = j; 
					data->size = value;
					 //Now create the thread passing it data as a parameter 
					//Create the thread
					pthread_create(&tid[count],NULL,runner,data);
					//Make sure the parent waits for all thread to complete
					pthread_join(tid[count], NULL);
					count++; 
					}
				}     
	printf("\n");
   //Print out the resulting matrix
   for(i = 0; i < value; i++) 
   {
      for(j = 0; j < value; j++) 
      {
         printf("\t%d", C[i][j]);
      }
      printf("\n");
   }
}

//The thread will begin control in this function
void *runner(void *param)
 	{
		struct v *data = param; // the structure that holds our data
		int n, sum = 0; //the counter and sum

		//Row multiplied by column
		for(n = 0; n< data->size; n++)
		{
		   sum += A[data->i][n] * B[n][data->j];
		}
   //assign the sum to its coordinate
   C[data->i][data->j] = sum;

   //Exit the thread
   pthread_exit(0);
	}


